import { GoogleGenAI, Type } from "@google/genai";

const socket = io();

// State Management
let stats = {
    total: 0,
    positive: 0,
    neutral: 0,
    negative: 0,
    ambiguous: 0,
    spam: 0,
    confidenceSum: 0,
};

let features = {
    battery: { positive: 0, negative: 0 },
    delivery: { positive: 0, negative: 0 },
    price: { positive: 0, negative: 0 },
    style: { positive: 0, negative: 0 },
    performance: { positive: 0, negative: 0 },
};

let languageCounts = {};
let latestReviews = [];
let aiActive = true; 

// Charts
let sentimentChart, featureChart;

function initCharts() {
    const isDark = document.documentElement.classList.contains('dark');
    const textColor = isDark ? '#94a3b8' : '#64748b';
    const gridColor = isDark ? '#1e293b' : '#f1f5f9';

    const ctx = document.getElementById('sentiment-chart').getContext('2d');
    sentimentChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Positive', 'Neutral', 'Negative', 'Ambiguous'],
            datasets: [{
                data: [0, 0, 0, 0],
                backgroundColor: ['#10b981', '#94a3b8', '#f43f5e', '#f59e0b'],
                borderWidth: 4,
                borderColor: isDark ? '#0f172a' : '#ffffff',
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { 
                legend: { display: false } 
            },
            cutout: '82%',
            animation: { animateRotate: true, animateScale: true }
        }
    });

    const ctx2 = document.getElementById('feature-chart').getContext('2d');
    featureChart = new Chart(ctx2, {
        type: 'bar',
        data: {
            labels: ['Battery', 'Delivery', 'Price', 'Style', 'Perf'],
            datasets: [
                {
                    label: 'Positive',
                    data: [0, 0, 0, 0, 0],
                    backgroundColor: '#10b981',
                    borderRadius: 6,
                    barThickness: 12
                },
                {
                    label: 'Negative',
                    data: [0, 0, 0, 0, 0],
                    backgroundColor: '#f43f5e',
                    borderRadius: 6,
                    barThickness: 12
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: { stacked: true, grid: { display: false }, ticks: { color: textColor, font: { size: 9, weight: 'bold' } } },
                y: { stacked: true, grid: { color: gridColor }, ticks: { color: textColor, font: { size: 9 } } }
            },
            plugins: { legend: { display: false } }
        }
    });
}

function updateUI() {
    document.getElementById('stat-total').textContent = stats.total.toLocaleString();
    const totalSent = stats.positive + stats.neutral + stats.negative + stats.ambiguous;
    const posPercent = totalSent > 0 ? Math.round((stats.positive / totalSent) * 100) : 0;
    document.getElementById('stat-sentiment').textContent = `${isNaN(posPercent) ? 0 : posPercent}%`;
    document.getElementById('sentiment-percentage').textContent = `${isNaN(posPercent) ? 0 : posPercent}%`;
    document.getElementById('sentiment-bar').style.width = `${posPercent}%`;
    
    document.getElementById('stat-ambiguous').textContent = stats.ambiguous;

    // Update Charts
    sentimentChart.data.datasets[0].data = [stats.positive, stats.neutral, stats.negative, stats.ambiguous];
    
    const isDark = document.documentElement.classList.contains('dark');
    sentimentChart.data.datasets[0].borderColor = isDark ? '#0f172a' : '#ffffff';
    
    sentimentChart.update();

    featureChart.data.datasets[0].data = Object.values(features).map(f => f.positive);
    featureChart.data.datasets[1].data = Object.values(features).map(f => f.negative);
    featureChart.update();

    updateLanguageBars();
    document.getElementById('buffer-count').textContent = latestReviews.length;
}

function updateLanguageBars() {
    const container = document.getElementById('confidence-bars');
    container.innerHTML = '';
    
    const totalCount = Object.values(languageCounts).reduce((a, b) => a + b, 0) || 1;
    const langs = Object.entries(languageCounts).sort((a,b) => b[1] - a[1]).slice(0, 4);
    
    langs.forEach(([lang, count]) => {
        const percent = Math.round((count / totalCount) * 100);
        const div = document.createElement('div');
        div.className = 'space-y-2';
        div.innerHTML = `
            <div class="flex justify-between text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                <span>${lang.toUpperCase()} SEGMENT</span>
                <span>${percent}%</span>
            </div>
            <div class="h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div class="h-full bg-indigo-500 transition-all duration-700" style="width: ${percent}%"></div>
            </div>
        `;
        container.appendChild(div);
    });
}

const colorClasses = {
    positive: 'border-l-emerald-500',
    negative: 'border-l-rose-500',
    neutral: 'border-l-slate-400',
    ambiguous: 'border-l-amber-500'
};

const textClasses = {
    positive: 'text-emerald-500 dark:text-emerald-400',
    negative: 'text-rose-500 dark:text-rose-400',
    neutral: 'text-slate-500 dark:text-slate-400',
    ambiguous: 'text-amber-500 dark:text-amber-400'
};

function addReviewToFeed(review) {
    const feed = document.getElementById('review-feed');
    if (feed.firstElementChild && feed.firstElementChild.innerText.includes('Awaiting First Data Block')) {
        feed.innerHTML = '';
    }

    const card = document.createElement('div');
    const lang = String(review.language || '??').toUpperCase();
    const sent = String(review.sentiment || 'neutral').toUpperCase();
    
    card.className = `review-card border-l-4 ${colorClasses[review.sentiment] || colorClasses.neutral}`;
    
    card.innerHTML = `
        <div class="flex justify-between items-center mb-2">
            <div class="flex items-center gap-2">
                <span class="text-[9px] font-black px-1.5 py-0.5 bg-slate-100 dark:bg-slate-700 rounded text-slate-500 dark:text-slate-400 uppercase tracking-widest">${lang}</span>
                <span class="text-[9px] font-black ${textClasses[review.sentiment] || textClasses.neutral} uppercase tracking-widest">${sent}</span>
                <span class="text-[8px] font-bold text-slate-400 uppercase tracking-tighter opacity-60">${review.category}</span>
            </div>
            <div class="flex items-center gap-1.5">
                <div class="w-16 h-1 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div class="h-full bg-indigo-500" style="width: ${Math.round(review.confidence * 100)}%"></div>
                </div>
                <span class="text-[9px] font-bold text-slate-400">${Math.round(review.confidence * 100)}%</span>
            </div>
        </div>
        <p class="text-xs font-medium text-slate-700 dark:text-slate-300 leading-relaxed">${review.text}</p>
        <div class="flex flex-wrap gap-2 mt-2">
            ${review.isSpam ? '<div class="text-[8px] font-black bg-rose-500/10 text-rose-600 dark:text-rose-400 px-1.5 py-0.5 rounded uppercase tracking-widest border border-rose-500/20">Spam Shield</div>' : ''}
            ${review.isSarcastic ? '<div class="text-[8px] font-black bg-amber-500/10 text-amber-600 dark:text-amber-400 px-1.5 py-0.5 rounded uppercase tracking-widest border border-amber-500/20">Sarcasm Detected</div>' : ''}
        </div>
    `;
    
    feed.prepend(card);
    if (feed.children.length > 50) feed.lastChild.remove();

    // Stats
    stats.total++;
    stats[review.sentiment]++;
    if (review.isSpam) stats.spam++;
    stats.confidenceSum += review.confidence;
    languageCounts[review.language] = (languageCounts[review.language] || 0) + 1;

    // Feature tracking
    Object.entries(review.features).forEach(([f, s]) => {
        if (features[f]) {
            if (s === 'positive') features[f].positive++;
            if (s === 'negative') features[f].negative++;
        }
    });

    latestReviews.push(review);
    if (latestReviews.length > 20) latestReviews.shift();

    // Trigger AI summary immediately when hitting minimum data threshold
    if (latestReviews.length === 5 && aiActive && !window.currentInsights) {
        generateAIInsights();
    }

    if (review.trendAlerts && review.trendAlerts.length > 0) {
        updateTrendAlerts(review.trendAlerts);
    }

    updateUI();
}

function updateTrendAlerts(alerts) {
    const container = document.getElementById('trend-alerts');
    container.innerHTML = '';
    alerts.forEach(alertText => {
        const div = document.createElement('div');
        div.className = 'p-3 bg-indigo-50 dark:bg-indigo-500/10 border-l-2 border-indigo-500 rounded-r-xl flex items-start gap-3 animate-in fade-in slide-in-from-left-4';
        div.innerHTML = `
            <svg class="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path></svg>
            <p class="text-[10px] font-bold text-slate-700 dark:text-slate-300 leading-tight uppercase tracking-tighter">${alertText}</p>
        `;
        container.appendChild(div);
    });
}

// AI Generation via Server
async function checkAIStatus() {
    try {
        const res = await fetch('/api/ai/status');
        const data = await res.json();
        const indicator = document.getElementById('ai-status-indicator');
        const aiBox = document.getElementById('ai-insights-content');
        if (!indicator || !aiBox) return;

        if (data.active) {
            indicator.textContent = 'ACTIVE';
            indicator.className = 'text-emerald-500';
            aiActive = true;
        } else {
            indicator.textContent = 'OFFLINE';
            indicator.className = 'text-rose-500';
            aiActive = false;
            if (aiBox.innerHTML.includes('pulse')) {
                aiBox.innerHTML = `
                    <div class="p-4 bg-rose-50 dark:bg-rose-500/10 border-l-2 border-rose-500 rounded-r-xl">
                        <p class="text-[10px] font-bold text-rose-600 dark:text-rose-400 uppercase tracking-tighter">Strategic Hub Offline: Please add GEMINI_API_KEY to secrets to activate Business Intelligence.</p>
                    </div>
                `;
            }
        }
    } catch (e) {
        console.warn("Status check failed");
    }
}

async function generateAIInsights() {
    if (!aiActive || latestReviews.length < 5) return;
    
    const contentDiv = document.getElementById('ai-insights-content');
    
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        const reviews = latestReviews.map(r => r.text);
        
        const prompt = `Act as an expert customer experience analyst. Based on these reviews:
        ${reviews.join('\n')}
        
        Analyze pain points, favorites, and urgent actions.
        Format labels as:
        - TOP PAIN POINT: [insight]
        - CUSTOMER FAVORITE: [insight]
        - STRATEGIC ACTION: [insight]
        
        Extremely concise, all caps.`;

        const result = await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: prompt
        });
        
        if (result.text) {
            const text = result.text;
            window.currentInsights = text;
            
            contentDiv.innerHTML = `<div class="text-[11px] font-bold text-slate-600 dark:text-slate-300 space-y-3 uppercase tracking-tighter leading-tight">
                ${text.split('\n').filter(l => l.trim()).map(line => `
                    <div class="flex gap-2">
                        <span class="text-indigo-500">▶</span>
                        <span>${line.replace(/^[\*•\d\.]+\s*/, '')}</span>
                    </div>
                `).join('')}
            </div>`;
        } else {
            console.warn("AI Insights pending: Check backend configuration.");
        }
    } catch (e) {
        console.error("Client-side AI Insights failed:", e);
    }
}

setInterval(generateAIInsights, 60000);

// File Upload
async function handleFiles(file) {
    const formData = new FormData();
    formData.append('file', file);
    
    const dropZone = document.getElementById('drop-zone');
    const originalContent = dropZone.innerHTML;
    dropZone.innerHTML = `
        <div class="flex flex-col items-center justify-center h-full">
            <div class="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mb-4"></div>
            <p class="text-[10px] font-black uppercase tracking-widest text-slate-500">Processing Infrastructure...</p>
        </div>
    `;

    try {
        const res = await fetch('/api/upload', { method: 'POST', body: formData });
        const data = await res.json();
        
        if (res.ok && data.reviews) {
            data.reviews.forEach(r => addReviewToFeed(r));
            if (data.trends) updateTrendAlerts(data.trends);
            
            dropZone.innerHTML = `
                <div class="flex flex-col items-center justify-center h-full text-emerald-500">
                    <svg class="w-10 h-10 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    <p class="text-[10px] font-black uppercase tracking-widest">${data.total} Units Processed</p>
                </div>
            `;
            setTimeout(() => { dropZone.innerHTML = originalContent; }, 3000);
        } else {
            throw new Error(data.error || 'Pipeline Failure');
        }
    } catch (e) {
        alert(e.message);
        dropZone.innerHTML = originalContent;
    }
}

// Event Listeners
const dropZone = document.getElementById('drop-zone');
const fileInput = document.getElementById('file-input');

if (dropZone) {
    dropZone.onclick = () => fileInput.click();
    dropZone.ondragover = (e) => { e.preventDefault(); dropZone.classList.add('bg-indigo-50/50'); };
    dropZone.ondragleave = () => dropZone.classList.remove('bg-indigo-50/50');
    dropZone.ondrop = (e) => {
        e.preventDefault();
        dropZone.classList.remove('bg-indigo-50/50');
        if (e.dataTransfer.files.length) handleFiles(e.dataTransfer.files[0]);
    };
}
fileInput.onchange = (e) => { if (e.target.files.length) handleFiles(e.target.files[0]); };

// Pipeline UI Update
function updatePipelineUI(active) {
    const statusText = document.getElementById('pipeline-status');
    const dot = document.getElementById('pipeline-dot');
    const btn = document.getElementById('pipeline-toggle');
    
    if (active) {
        statusText.textContent = 'LIVE';
        dot.classList.add('animate-pulse', 'bg-emerald-500');
        dot.classList.remove('bg-slate-400');
        btn.classList.add('text-emerald-600', 'bg-emerald-500/10', 'border-emerald-500/20');
        btn.classList.remove('text-slate-500', 'bg-slate-500/10', 'border-slate-500/20');
    } else {
        statusText.textContent = 'PAUSED';
        dot.classList.remove('animate-pulse', 'bg-emerald-500');
        dot.classList.add('bg-slate-400');
        btn.classList.remove('text-emerald-600', 'bg-emerald-500/10', 'border-emerald-500/20');
        btn.classList.add('text-slate-500', 'bg-slate-500/10', 'border-slate-500/20');
    }
}

// Pipeline Toggle
const pipelineToggle = document.getElementById('pipeline-toggle');
if (pipelineToggle) {
    pipelineToggle.onclick = async () => {
        try {
            const res = await fetch('/api/simulation/toggle', { method: 'POST' });
            const data = await res.json();
            updatePipelineUI(data.active);
        } catch (e) {
            console.error("Failed to toggle simulation:", e);
        }
    };
}

// Theme Toggle
const themeToggle = document.getElementById('theme-toggle');
themeToggle.onclick = () => {
    const isDark = document.documentElement.classList.toggle('dark');
    const text = document.getElementById('theme-text');
    const icon = document.getElementById('theme-icon');
    
    if (isDark) {
        text.textContent = 'Light Mode';
        icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 9h-1m15.364-6.364l-.707.707M6.343 17.657l-.707.707m12.728 0l-.707-.707M6.343 6.343l-.707-.707M12 5a7 7 0 100 14 7 7 0 000-14z"></path>';
    } else {
        text.textContent = 'Dark Mode';
        icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"></path>';
    }
    
    // Refresh chart styles for new theme
    sentimentChart.destroy();
    featureChart.destroy();
    initCharts();
    updateUI();
};

// PDF Report
document.getElementById('download-report').onclick = () => {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const primary = "#4f46e5";
    
    doc.setFillColor( primary );
    doc.rect(0, 0, 210, 40, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(24);
    doc.text("Executive Intelligence Report", 15, 25);
    
    doc.setTextColor(100, 100, 100);
    doc.setFontSize(10);
    doc.text(`DATE: ${new Date().toLocaleString().toUpperCase()}`, 15, 50);
    
    doc.setFontSize(14);
    doc.setTextColor(50, 50, 50);
    doc.text("Operational KPIs", 15, 70);
    doc.line(15, 72, 60, 72);
    
    doc.setFontSize(11);
    doc.text(`- TOTAL PROCESSED: ${stats.total}`, 15, 85);
    doc.text(`- POSITIVE BIAS: ${document.getElementById('stat-sentiment').textContent}`, 15, 95);
    doc.text(`- SPAM ATTACKS DEFLECTED: ${stats.spam}`, 15, 105);
    doc.text(`- AVERAGE ML CONFIDENCE: ${document.getElementById('stat-confidence').textContent}`, 15, 115);
    
    doc.setFontSize(14);
    doc.text("AI Strategic Guidance", 15, 140);
    doc.line(15, 142, 70, 142);
    
    doc.setFontSize(10);
    const insights = window.currentInsights || "Diagnostic period active. No strategic insights cached.";
    const splitText = doc.splitTextToSize(insights, 180);
    doc.text(splitText, 15, 155);
    
    doc.save(`hub-intelligence-prime-${Date.now()}.pdf`);
};

// Voice Hub
const speakBtn = document.getElementById('speak-insights');
speakBtn.onclick = () => {
    if (!window.currentInsights || window.currentInsights.trim() === "") {
        const utter = new SpeechSynthesisUtterance("Intelligence Hub is currently identifying data points. Please wait for insights to generate.");
        window.speechSynthesis.cancel();
        window.speechSynthesis.speak(utter);
        return;
    }

    // Clean text for clearer speech
    let cleanText = window.currentInsights
        .replace(/TOP PAIN POINT:/g, 'The top pain point identified is ')
        .replace(/CUSTOMER FAVORITE:/g, 'The customer favorite is ')
        .replace(/STRATEGIC ACTION:/g, 'The strategic action recommended is ')
        .replace(/STRATEGIC ACTION/g, 'The strategic action recommended is ')
        .replace(/[\*\#\@]/g, '')
        .replace(/\s+/g, ' ')
        .trim();

    const intro = "Hearing Insights from Review Intel Intelligence Engine. ";
    const fullSpeech = intro + cleanText;

    const utterance = new SpeechSynthesisUtterance(fullSpeech);
    utterance.rate = 1.0; 
    utterance.pitch = 0.95; 
    
    window.speechSynthesis.cancel(); 
    
    const originalHTML = speakBtn.innerHTML;
    speakBtn.innerHTML = `
        <span class="flex items-center gap-2">
            <span class="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
            SPEAKING...
        </span>
    `;
    speakBtn.classList.add('bg-emerald-50', 'text-emerald-600');

    utterance.onend = () => {
        speakBtn.innerHTML = originalHTML;
        speakBtn.classList.remove('bg-emerald-50', 'text-emerald-600');
    };

    window.speechSynthesis.speak(utterance);
};

// Agent Commander
const agentInput = document.getElementById('agent-command');
const agentBtn = document.getElementById('send-agent-command');
const agentTicker = document.getElementById('agent-logs-ticker');
const voiceBtn = document.getElementById('voice-command-btn');
const commandGuide = document.getElementById('command-guide');
const showCommandsBtn = document.getElementById('show-commands');

showCommandsBtn.onclick = () => commandGuide.classList.toggle('hidden');

// Agent Voice Engine
function speakAgentResponse(text) {
    if (!text) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.1;
    utterance.pitch = 1.0;
    const voices = window.speechSynthesis.getVoices();
    const premiumVoice = voices.find(v => v.name.includes('Google') || v.name.includes('Premium'));
    if (premiumVoice) utterance.voice = premiumVoice;
    window.speechSynthesis.speak(utterance);
}

// Update Agent Ticker
function updateAgentTicker(msg, isAction = false) {
    agentTicker.textContent = msg;
    agentTicker.classList.add('animate-pulse');
    if (isAction) {
        agentTicker.classList.add('text-indigo-500');
    }
    setTimeout(() => {
        agentTicker.classList.remove('animate-pulse');
    }, 2000);
}

// Voice Recognition
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.lang = 'en-US';
    recognition.interimResults = false;

    recognition.onstart = () => {
        voiceBtn.classList.add('animate-pulse', 'text-rose-500');
        agentInput.placeholder = "Listening...";
        
        const avatar = document.getElementById('listening-avatar');
        if (avatar) {
            avatar.classList.remove('opacity-0', 'scale-50', 'pointer-events-none');
            avatar.classList.add('opacity-100', 'scale-100');
        }
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        agentInput.value = transcript;
        sendAgentCommand();
    };

    recognition.onend = () => {
        voiceBtn.classList.remove('animate-pulse', 'text-rose-500');
        agentInput.placeholder = "Instruct AI Agent...";
        
        const avatar = document.getElementById('listening-avatar');
        if (avatar) {
            avatar.classList.replace('opacity-100', 'opacity-0');
            avatar.classList.replace('scale-100', 'scale-50');
            avatar.classList.add('pointer-events-none');
        }
    };

    recognition.onerror = (event) => {
        console.error("[VOICE ERROR]", event.error);
        voiceBtn.classList.remove('animate-pulse', 'text-rose-500');
        agentInput.placeholder = `Protocol Error: ${event.error}`;
        
        const avatar = document.getElementById('listening-avatar');
        if (avatar) {
            avatar.classList.replace('opacity-100', 'opacity-0');
            avatar.classList.replace('scale-100', 'scale-50');
            avatar.classList.add('pointer-events-none');
        }
    };

    voiceBtn.onclick = () => {
        try {
            recognition.start();
        } catch (e) {
            console.warn("Recognition already active or failed:", e);
        }
    };
} else {
    voiceBtn.onclick = () => {
        updateAgentTicker("VOICE MODULE NOT SUPPORTED IN THIS BROWSER");
    };
}

async function sendAgentCommand() {
    const cmd = agentInput.value.trim();
    if (!cmd) return;

    agentInput.value = '';
    agentInput.disabled = true;
    updateAgentTicker(`PROCESSING: ${cmd.toUpperCase()}`);

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        
        const tools = [
            {
                functionDeclarations: [
                    {
                        name: "toggle_simulation",
                        description: "Starts or stops the live review simulation pipeline.",
                        parameters: {
                            type: Type.OBJECT,
                            properties: {
                                active: { type: Type.BOOLEAN, description: "Whether the simulation should be active or not." }
                            },
                            required: ["active"]
                        }
                    },
                    {
                        name: "flag_critical_issue",
                        description: "Flags a specific topic (like 'battery' or 'delivery') as a high-priority business emergency.",
                        parameters: {
                            type: Type.OBJECT,
                            properties: {
                                topic: { type: Type.STRING, description: "The feature or topic to flag." },
                                severity: { type: Type.STRING, description: "The severity level (CRITICAL, SEVERE, MODERATE)." }
                            },
                            required: ["topic", "severity"]
                        }
                    }
                ]
            }
        ];

        const response = await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: [{ parts: [{ text: cmd }] }],
            config: {
                systemInstruction: `You are the Lead Strategic Agent for ReviewIntel. 
                You have access to live dashboard controls. 
                When a user asks to start/stop or pause/resume the simulation, use the toggle_simulation tool.
                Current Context: ${JSON.stringify({ stats, latestReviews: latestReviews.slice(-5) })}`,
                tools: tools
            }
        });

        const functionCalls = response.functionCalls;
        let agentMessage = response.text || "";

        if (functionCalls) {
            for (const call of functionCalls) {
                if (call.name === "toggle_simulation") {
                    const res = await fetch('/api/simulation/toggle', { 
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ active: call.args.active })
                    });
                    const data = await res.json();
                    updatePipelineUI(data.active);
                    agentMessage = agentMessage || (data.active ? "Simulation resumed." : "Simulation paused.");
                }
                if (call.name === "flag_critical_issue") {
                    await fetch('/api/agent/flag-issue', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ topic: call.args.topic, severity: call.args.severity })
                    });
                    agentMessage = agentMessage || `Critical alert broadcasted for ${call.args.topic}.`;
                }
            }
        }

        if (agentMessage) {
            updateAgentTicker(agentMessage.substring(0, 50) + "...");
            speakAgentResponse(agentMessage);
        }

    } catch (e) {
        console.error("[AGENT ERROR]", e);
        updateAgentTicker("PROTOCOL ERROR");
    } finally {
        agentInput.disabled = false;
        agentInput.focus();
    }
}

agentBtn.onclick = sendAgentCommand;
agentInput.onkeydown = (e) => { if (e.key === 'Enter') sendAgentCommand(); };

// Socket Stream
socket.on('new-review', (review) => {
    addReviewToFeed(review);
});

socket.on('agent-alert', (alert) => {
    const alertEntry = document.createElement('div');
    alertEntry.className = 'p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl mb-3 animate-bounce';
    alertEntry.innerHTML = `
        <div class="flex items-center gap-2 mb-1">
            <span class="w-2 h-2 bg-rose-500 rounded-full"></span>
            <span class="text-[9px] font-black uppercase tracking-widest text-rose-600">AGENT ALERT</span>
        </div>
        <p class="text-[10px] font-bold text-rose-700 dark:text-rose-400">CRITICAL ISSUE IDENTIFIED: ${alert.topic.toUpperCase()} (${alert.severity})</p>
    `;
    document.getElementById('trend-alerts').prepend(alertEntry);
});

// Event listeners for category selectors
document.querySelectorAll('.category-selector').forEach(btn => {
    btn.onclick = async () => {
        const cat = btn.dataset.cat;
        try {
            const res = await fetch('/api/simulation/category', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ category: cat })
            });
            const data = await res.json();
            if (data.success) {
                // Reset Active UI
                document.querySelectorAll('.category-selector').forEach(b => {
                    b.classList.remove('bg-indigo-500', 'text-white', 'shadow-lg', 'shadow-indigo-500/20');
                    b.classList.add('text-slate-500', 'hover:bg-slate-100', 'dark:hover:bg-slate-800');
                    const dot = b.querySelector('span');
                    if (dot) dot.className = 'w-2 h-2 rounded-full bg-slate-300';
                });
                btn.classList.add('bg-indigo-500', 'text-white', 'shadow-lg', 'shadow-indigo-500/20');
                btn.classList.remove('text-slate-500', 'hover:bg-slate-100', 'dark:hover:bg-slate-800');
                const dot = btn.querySelector('span');
                if (dot) dot.className = 'w-2 h-2 rounded-full bg-white animate-pulse';
                
                document.getElementById('active-category-display').textContent = cat.toUpperCase();
                updateAgentTicker(`ORCHESTRATION: SWITCHING TO ${cat.toUpperCase()} CATEGORY`, true);
            }
        } catch (e) {
            console.error("Category switch failed", e);
        }
    };
});

// Sidebar Navigation
const navItems = {
    'nav-dashboard': null,
    'nav-analytics': 'analytics-section',
    'nav-insights': 'insights-section'
};

Object.entries(navItems).forEach(([navId, targetId]) => {
    const el = document.getElementById(navId);
    if (!el) return;
    
    el.onclick = () => {
        // Handle Active State
        document.querySelectorAll('#nav-dashboard, #nav-analytics, #nav-insights').forEach(item => {
            item.classList.remove('bg-indigo-50', 'dark:bg-indigo-500/10', 'text-indigo-600', 'dark:text-indigo-400', 'font-bold');
            item.classList.add('text-slate-500', 'font-medium');
        });
        
        el.classList.add('bg-indigo-50', 'dark:bg-indigo-500/10', 'text-indigo-600', 'dark:text-indigo-400', 'font-bold');
        el.classList.remove('text-slate-500', 'font-medium');
        
        if (targetId) {
            const target = document.getElementById(targetId);
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                updateAgentTicker(`NAVIGATION: SCROLLING TO ${navId.split('-')[1].toUpperCase()} MODULE`, true);
            }
        } else {
            window.scrollTo({ top: 0, behavior: 'smooth' });
            updateAgentTicker(`NAVIGATION: RETURNING TO OPERATIONS HUB`, true);
        }
    };
});

// Init
initCharts();
updateUI();
checkAIStatus().then(() => {
    // If already have 5+ reviews from a previous session/manual upload, call insights immediately
    if (latestReviews.length >= 5) generateAIInsights();
});
setInterval(checkAIStatus, 10000);
