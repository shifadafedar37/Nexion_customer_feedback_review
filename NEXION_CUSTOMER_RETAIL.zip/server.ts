import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import path from "path";
import multer from "multer";
import cors from "cors";
import { parse } from "csv-parse/sync";
import { detect } from "langdetect";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
    }
  });

  const PORT = 3000;

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  const upload = multer({ storage: multer.memoryStorage() });

  // Robust NLP Helpers
  const emojiMap: Record<string, 'positive' | 'negative' | 'neutral'> = {
    '😊': 'positive', '😍': 'positive', '🔥': 'positive', '👍': 'positive', '❤️': 'positive', '🙌': 'positive', '🌟': 'positive',
    '😡': 'negative', '👎': 'negative', '🤮': 'negative', '💩': 'negative', '🤬': 'negative', '💔': 'negative', '😞': 'negative',
    '🤔': 'neutral', '😐': 'neutral', '😶': 'neutral'
  };

  const slangMap: Record<string, string> = {
    'gud': 'good', 'bakwas': 'bad', 'mast': 'great', 'thik': 'okay', 'bekar:': 'bad', 'awsm': 'awesome',
    'v': 'very', 'u': 'you', 'r': 'are', 'n': 'and', 'gr8': 'great', 'baddd': 'bad', 'nyc': 'nice',
    'productt': 'product', 'qualityy': 'quality', 'waste': 'bad'
  };

  const normalizeText = (text: string) => {
    // 1. Convert emojis to sentiment hints (pre-cleaning)
    let emojiSentiment: 'positive' | 'negative' | 'neutral' | null = null;
    for (const [emoji, sent] of Object.entries(emojiMap)) {
      if (text.includes(emoji)) {
        emojiSentiment = sent;
        break;
      }
    }

    // 2. Reduce repeated characters (e.g., "goooood" -> "good")
    let normalized = text.toLowerCase().replace(/(.)\1{2,}/g, '$1$1');
    
    // 3. Slang replacement
    const words = normalized.split(/\s+/);
    normalized = words.map(w => slangMap[w] || w).join(' ');

    return { normalized, emojiSentiment };
  };

  // Review processing logic
  let reviewHistory: any[] = [];
  const MAX_HISTORY = 200;

  let currentCategory = "Smartphones";

  const processReview = (text: string) => {
    const { normalized, emojiSentiment } = normalizeText(text);
    
    // Sarcasm Detection (Keyword & Context based)
    const sarcasmSignals = [
      'great job', 'perfect if you want', 'amazing if you like', 'wonderful, the', 
      'lovely', 'just what i needed', 'sarcasm', '🙄', 'not.'
    ];
    const isSarcastic = sarcasmSignals.some(s => normalized.includes(s));

    // Basic Sentiment
    let sentiment: 'positive' | 'neutral' | 'negative' | 'ambiguous' = emojiSentiment || 'neutral';
    if (isSarcastic) {
      sentiment = 'ambiguous';
    } else {
      const posWords = ['good', 'great', 'awesome', 'excellent', 'best', 'happy', 'love', 'fantastic', 'better', 'smooth', 'worth', 'perfect'];
      const negWords = ['bad', 'worst', 'horrible', 'poor', 'slow', 'expensive', 'broken', 'disappointed', 'delay', 'issue', 'complaint', 'waste', 'regret'];
      
      let score = 0;
      posWords.forEach(w => { if (normalized.includes(w)) score++; });
      negWords.forEach(w => { if (normalized.includes(w)) score--; });
      
      if (score > 0) sentiment = 'positive';
      else if (score < 0) sentiment = 'negative';
    }

    // Feature Extraction
    const features: Record<string, string> = {};
    const featureKeywords = {
      battery: ['battery', 'charge', 'power', 'backup', 'drain', 'ac', 'fridge'],
      delivery: ['delivery', 'shipping', 'packaging', 'tracking', 'delay', 'arrived'],
      price: ['price', 'cost', 'expensive', 'cheap', 'budget', 'money', 'value'],
      style: ['style', 'design', 'fit', 'look', 'fabric', 'stitching', 'color'],
      performance: ['performance', 'fast', 'slow', 'lag', 'speed', 'processing', 'cooling', 'wash']
    };

    Object.entries(featureKeywords).forEach(([feature, keywords]) => {
      if (keywords.some(k => normalized.includes(k))) {
        features[feature] = sentiment;
      }
    });

    // Language Detection
    let language = 'en';
    try {
      const detected = detect(text);
      if (typeof detected === 'string') {
        language = detected;
      } else if (Array.isArray(detected) && detected.length > 0) {
        language = (detected[0] as any).lang || 'en';
      }
    } catch (e) {
      if (/[\u0900-\u097F]/.test(text)) language = 'hi';
      else if (/[\u0C80-\u0CFF]/.test(text)) language = 'kn';
      else language = 'en';
    }

    // Spam detection: pattern check + short length
    const isSpam = text.length < 5 || 
                   (new Set(normalized.split(' ')).size / normalized.split(' ').length < 0.3) ||
                   reviewHistory.some(prev => prev.text === text);

    const result = {
      text,
      normalized,
      sentiment,
      isSarcastic,
      category: currentCategory,
      features,
      language,
      isSpam,
      confidence: isSarcastic ? 0.45 : (0.75 + Math.random() * 0.20),
      timestamp: new Date().toISOString()
    };

    reviewHistory.push(result);
    if (reviewHistory.length > MAX_HISTORY) reviewHistory.shift();
    
    return result;
  };

  // Simulated datasets for multiple categories
  const categories: Record<string, string[]> = {
    "Smartphones": [
      "The battery is gooooooood! 😍",
      "delivery baddd, delay is worsttt 😡",
      "gud camera quality, awsm photography",
      "paiso ki barbadi, bakwas product",
      "Value for money, performance mast hai!!",
      "battery drain issue.. not good",
      "best camera evr... love it ❤️",
      "arrived late but product is gr8",
      "hung again... very slow performance",
      "Great, another delay. Just what I needed. 🙄",
      "The camera is 'amazing' if you like blurry photos.",
      "Oh lovely, it started overheating after 5 minutes."
    ],
    "Appliances": [
      "AC cooling is super fast! ❄️",
      "The fridge makes a loud noise at night 🔊",
      "Mast washing machine, clean cloths!!",
      "Service center is very far, bekar support",
      "Electricity bill increased, not energy efficient 👎",
      "Premium build quality, looks rich.",
      "Microwave is 'perfect' if you want cold food. 🙄",
      "Installation was so fast, only took 3 weeks. Great. 🙄",
      "Thanks for delivering a dented fridge. Great job. 🤬"
    ],
    "Fashion": [
      "Fabric is very soft, love the fit!",
      "Color faded after one wash, bekar quality",
      "Style is awsm, everyone asked about it",
      "Size is too small, check chart before buying",
      "Delivery was quick, packing mast hai",
      "The stitching is 'fine' if you don't mind holes. 🙄",
      "Wonderful, the shirt is basically transparent. 🙄",
      "I love waiting 15 days for a t-shirt. Not."
    ]
  };

  const getTrendAnalysis = () => {
    const categoryHistory = reviewHistory.filter(r => r.category === currentCategory);
    if (categoryHistory.length < 15) return { trends: [], classification: 'Isolated' };

    const recent = categoryHistory.slice(-10);
    const older = categoryHistory.slice(0, Math.max(0, categoryHistory.length - 10));
    
    const recentNeg = recent.filter(r => r.sentiment === 'negative').length / recent.length;
    const olderNeg = older.filter(r => r.sentiment === 'negative' || r.sentiment === 'ambiguous').length / older.length;

    const trends = [];
    if (recentNeg > olderNeg * 1.5) {
      trends.push(`Strategic Alert: Negative feedback for ${currentCategory} increased significantly recently.`);
    }

    // Feature trends
    const featuresToCheck = ['delivery', 'battery', 'performance', 'style'];
    featuresToCheck.forEach(feat => {
        const featRecentNeg = recent.filter(r => r.features[feat] === 'negative').length;
        if (featRecentNeg > 3) {
            trends.push(`Pattern Detected: Rising ${feat.toUpperCase()} complaints in ${currentCategory}.`);
        }
    });

    return {
      trends,
      classification: trends.length > 1 ? 'Systemic' : 'Isolated',
      stats: { recentNeg, olderNeg }
    };
  };

  /* 
    REAL API REALITY CHECK:
    - Official APIs (like Google Maps or Notion) require OAuth or a permanent API Key.
    - Public web scraping is often blocked by robots.txt or Cloudflare.
    - In a real production app, we would use a Webhook from Stripe/Shopify 
      or a scheduled Cron job to poll Official APIs.
    - Below we simulate the 'Fetch' action via a Mock API interface.
  */

  // Simulation Control
  let simulationActive = true;

  setInterval(() => {
    if (!simulationActive) return;
    const catReviews = categories[currentCategory];
    const rawReview = catReviews[Math.floor(Math.random() * catReviews.length)];
    const processed = processReview(rawReview);
    const trends = getTrendAnalysis();
    io.emit('new-review', { ...processed, trendAlerts: trends.trends });
  }, 4000);

  /* 
    AGENTIC ACTION ENDPOINTS
    These are the "hands" that the Strategic Agent uses to control the system.
  */
  app.post("/api/simulation/toggle", (req, res) => {
    const { active } = req.body;
    if (active !== undefined) {
      simulationActive = active;
    } else {
      simulationActive = !simulationActive;
    }
    res.json({ active: simulationActive });
  });

  app.post("/api/simulation/category", (req, res) => {
    const { category } = req.body;
    if (categories[category]) {
      currentCategory = category;
      res.json({ category: currentCategory, success: true });
    } else {
      res.status(400).json({ error: "Invalid category" });
    }
  });

  app.post("/api/agent/flag-issue", (req, res) => {
    const { topic, severity } = req.body;
    io.emit('agent-alert', { topic, severity });
    res.json({ status: "success", topic, severity });
  });

  app.post("/api/ai/insights", async (req, res) => {
    // This is now handled on the client side for maximum responsiveness.
    res.status(410).json({ error: "Endpoint deprecated. Use Strategic Client Proxy." });
  });

  app.post("/api/upload", upload.single('file'), (req: any, res: any) => {
    console.log(`[Upload] Received request for file: ${req.file?.originalname}`);
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    const fileName = req.file.originalname.toLowerCase();
    const content = req.file.buffer.toString();
    let reviews: any[] = [];

    try {
      if (fileName.endsWith('.csv')) {
        const records = parse(content, { columns: true, skip_empty_lines: true });
        reviews = records.map((r: any) => r.review || r.text || r.Review || r.Text || Object.values(r)[0]);
      } else if (fileName.endsWith('.json')) {
        const data = JSON.parse(content);
        if (Array.isArray(data)) reviews = data.map(r => r.review || r.text || r);
        else if (data.reviews) reviews = data.reviews.map((r: any) => r.review || r.text || r);
      }
    } catch (e) {
      return res.status(500).json({ error: "Parsing error" });
    }

    const processedReviews = reviews.map(r => processReview(String(r)));
    const trends = getTrendAnalysis();
    
    res.json({ 
      success: true,
      total: processedReviews.length, 
      reviews: processedReviews,
      trends: trends.trends,
      issue_classification: trends.classification
    });
  });

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: new Date().toISOString() });
  });

  app.get("/api/ai/status", (req, res) => {
    const apiKey = process.env.GEMINI_API_KEY;
    const isConfigured = !!apiKey && apiKey !== "MY_GEMINI_API_KEY" && apiKey.length > 10;
    res.json({ active: isConfigured });
  });

  // API 404 Catch-all (to prevent falling through to SPA index.html)
  app.use("/api/*", (req, res) => {
    res.status(404).json({ error: `API Route Not Found: ${req.method} ${req.originalUrl}` });
  });

  // Vite integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();

